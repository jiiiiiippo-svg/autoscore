# Autoscore landing

## Structure

```text
autoscore_project_files/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── public/
│   ├── autoscore-landing.png
│   ├── favicon.ico
│   ├── favicon-16x16.png
│   ├── favicon-32x32.png
│   ├── favicon-48x48.png
│   ├── favicon-64x64.png
│   ├── favicon-128x128.png
│   ├── favicon-192x192.png
│   ├── favicon-256x256.png
│   ├── favicon-512x512.png
│   └── apple-touch-icon.png
├── page.html
└── package.json
```

## Utilisation Next.js

1. Copie le dossier `public` dans ton projet Next.js.
2. Copie les fichiers `app/page.tsx`, `app/layout.tsx`, `app/globals.css`.
3. Lance :

```bash
npm install
npm run dev
```

## Utilisation HTML simple

Ouvre `page.html` et garde le dossier `public` au même niveau.
