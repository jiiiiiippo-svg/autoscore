export default function Home() {
  return (
    <main
      aria-label="Autoscore — Coming soon"
      className="min-h-screen w-full bg-cover bg-top bg-no-repeat"
      style={{ backgroundImage: "url('/autoscore-landing.png')" }}
    />
  );
}
